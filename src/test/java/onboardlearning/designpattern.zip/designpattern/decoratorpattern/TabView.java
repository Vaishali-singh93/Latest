package onboardlearning.designpattern.decoratorpattern;

public class TabView implements Webpage {
    @Override
    public int getRank() {
        return 6;
    }
}
