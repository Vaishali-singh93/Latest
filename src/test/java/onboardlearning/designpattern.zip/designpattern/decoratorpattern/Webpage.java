package onboardlearning.designpattern.decoratorpattern;

public interface Webpage {
    public int getRank();
}
