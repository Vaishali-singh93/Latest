package onboardlearning.designpattern.decoratorpattern;

public class DesktopView implements Webpage{
    @Override
    public int getRank() {
        return 2;
    }
}
