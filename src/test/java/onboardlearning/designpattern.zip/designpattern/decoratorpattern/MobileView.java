package onboardlearning.designpattern.decoratorpattern;

public class MobileView implements Webpage{
    @Override
    public int getRank() {
        return 4;
    }
}
