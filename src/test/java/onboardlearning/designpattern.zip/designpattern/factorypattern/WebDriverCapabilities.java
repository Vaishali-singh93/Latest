package onboardlearning.designpattern.factorypattern;

public interface WebDriverCapabilities {
    public void getDriver();
}
