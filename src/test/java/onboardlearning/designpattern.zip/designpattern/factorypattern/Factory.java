package onboardlearning.designpattern.factorypattern;

public interface Factory {
    public WebDriverCapabilities getCapability(String driverType);
}
