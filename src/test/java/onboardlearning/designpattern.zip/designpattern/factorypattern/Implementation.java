package onboardlearning.designpattern.factorypattern;

import java.util.Scanner;

public class Implementation {
    public static void main(String[] args) {
        Factory factory=null;
        Scanner sc = new Scanner(System.in);
        System.out.println("enter type of driver to initialize like chrome , firefox ,internerexplorer or add capability after browser name");
        String driverType = sc.nextLine();
        if(!driverType.contains("capability")){
           factory  = new DriverFactory();
        } else {
            factory = new CapabilityFactory();
        }
        GetFactory get = new GetFactory(factory);
        get.getBrowser(driverType);
    }
}
