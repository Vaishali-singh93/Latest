package onboardlearning.designpattern.strategypattern;

public interface PhoneCameraApp {
    public void share();

    private void takePhoto() {

    }

    private void editPhoto() {

    }

    private void sharePhoto() {

    }
}
